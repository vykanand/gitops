Go to the parent directory where you have all your darpan 2 git repositories.
Compress all the contents of this zip file into that folder containing all the git repositories.

Open Bash terminal and run:-  

# sudo chmod +x installer-script.sh && sudo ./installer-script.sh